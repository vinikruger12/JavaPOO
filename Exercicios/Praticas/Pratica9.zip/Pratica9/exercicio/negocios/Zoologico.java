package negocios;
import java.util.ArrayList;
import java.util.List;
import dados.*;
import exceptions.*;

public class Zoologico {
    private List<Animal> animais = new ArrayList<>(); 
    private List<Viveiro> viveiros = new ArrayList<>();

    public void cadastrarViveiro(Viveiro viveiro){
        viveiros.add(viveiro);
    }

    public void cadastrarAnimal(Animal animal){
        animais.add(animal);
    }

    public boolean alocarAnimal(Animal animal, Viveiro viveiro) throws EspacoIndisponivelException{
        
        boolean ok = viveiro.adicionarAnimal(animal);
        if(!ok){
            throw new EspacoIndisponivelException("Sem espaço disponível");
        }
        
        return ok;
        
    }

    public List<Aquario> getSoAquarios(){
        List<Aquario> listaAquarios = new ArrayList<>();
        for(Viveiro aq : viveiros){
            if(aq instanceof Aquario) listaAquarios.add((Aquario) aq);
        }
        return listaAquarios;
    }

    public List<Viveiro> getSoViveiros(){
        List<Viveiro> listaViveiros = new ArrayList<>();
        for(Viveiro v : viveiros){
            if(v instanceof Viveiro && !(v instanceof Aquario)) listaViveiros.add((Viveiro) v);
        }
        return listaViveiros;
    }


}
